""" random module is used for random number generations and making random choices"""

import random
a = random.random()                # Returns a random float between 0 and 1. Each time it will return another value
print('random.random() =', a)
a = random.randint(1, 10)          # Returns random integer within a specifien range
print('random.randint(1, 10) =', a)                  
print()

my_list = ['a', 12, 0.2, True, 'Andrii']
a = random.choice(my_list)                 # Returns a random element from a sequence
print('random.choice(my_list) =', a)
print()


