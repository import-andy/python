"""used to be imported"""

def imported():
    print('Hello, you imported me')
    pass